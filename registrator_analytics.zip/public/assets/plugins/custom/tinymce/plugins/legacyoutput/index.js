// Exports the "legacyoutput" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/legacyoutput')
//   ES2015:
//     import 'tinymce/plugins/legacyoutput'
require('./plugin.js');