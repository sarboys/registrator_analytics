@extends('layouts.app')

@section('content')
    Партнеры
@endsection
