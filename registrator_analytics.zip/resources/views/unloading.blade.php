@extends('layouts.app')

@section('content')
    Выгрузки
@endsection
