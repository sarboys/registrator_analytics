@extends('layouts.app')

@section('content')
    Продукты
@endsection
