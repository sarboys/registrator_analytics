

<?php $__env->startSection('content'); ?>
    Выгрузки
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\79999\PhpstormProjects\laravel\registrator_analytics\resources\views/unloading.blade.php ENDPATH**/ ?>